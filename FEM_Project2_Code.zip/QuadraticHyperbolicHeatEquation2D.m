% 2D hyperbolic heat equation with quadratic elements

%% Set parameters

m = 20;      % Number of grid nodes along each axis
N = m^2;      % Total number of nodes
n = m;
s = 3;        % Number of additional midpoints between nodes (for interpolation)
K = 2*(s+1)*(m-1) + 1; % Total number of points along each axis
D = 5e1;     % Thermal diffusivity
T1 = 0;     
T2 = 1;     % Dirichlet boundary values
k = 50;    % Time step
tau = 1e6;  % Relaxation time

%% Triangulation

T = zeros((n-1)*(m-1),1);
for i = 1:(n-1)
    T(1+(m-1)*(i-1):(m-1)*i) = (1+m*(i-1):m*i-1)';
end
tri = [T,T+1,T+m;T+m+1,T+m,T+1];

east = reshape([(m:m:N);[(m^2+1+3*(m-1):(3*m-2):(2*m-1)^2),0]],[],1); east(end) = [];
west = reshape([(N-m+1:-m:1);[(((2*m-1)^2-3*(m-1)):(2-3*m):m^2),0]],[],1); west(end) = [];
north = reshape([(N:-1:N-m+1);[(2*m-1)^2:-1:((2*m-1)^2-m+2),0]],[],1); north(end) = [];
south = reshape([(1:m);[(m^2+1):(m^2+m-1),0]],[],1); south(end) = [];

edge = [south,[south(2:end);east(2)];...
    east(2:end-1),east(3:end);...
    north,[north(2:end);east(2)];...
    west(2:end-1),west(3:end)];

V = zeros(size(tri,1),6);
V(:,1:2:5) = tri;
mid1 = zeros((n-1)*(m-1),1);
mid2 = zeros((n-1)*(m-1),1);
for i = 1:(n-1)
    mid1(1+(m-1)*(i-1):(m-1)*i) = (1+m*n+(3*m-2)*(i-1):m*(n+1)+(3*m-2)*(i-1)-1)';
    mid2(1+(m-1)*(i-1):(m-1)*i) = mid1(1+(m-1)*(i-1):(m-1)*i) + (m:2*(m-1))';
end
mid3 = mid2 - 1;
V(:,2) = [mid1;mid1+3*m-2];
V(:,4) = [mid2;mid2];
V(:,6) = [mid3;mid3+2];
[y,x] = meshgrid(linspace(-1,1,2*m-1), linspace(-1,1,2*m-1));
p = [x(:), y(:)];
ext = false(size(p,1),1);
for i = 1:m
    ext((1+(4*m-2)*(i-1):2:(2*m-1)*(2*i-1))) = true;
end
pext = p(ext,:);
pint = p(~ext,:);
p = [pext;pint];

%% Boundary conditions and initial values
Dir1 = west;
Dir2 = east;

B = edge(:,1);      % All boundary nodes

Rg = zeros(size(p,1),1);  
Rg(Dir1) = T1;
Rg(Dir2) = T2;      % Lifting vector

T = 0*p(:,1);
T(B) = Rg(B); 
T = [T;zeros(length(T),1)]; % Initial data

%% Create system matrices

x1 = p(tri(:,1),:);
x2 = p(tri(:,2),:);
x3 = p(tri(:,3),:); 

J = [x1-x3,x2-x3];

Jdet = abs(J(:,4).*J(:,1) - J(:,2).*J(:,3)); % Jacobian for all elements

MInt = (1/360)*sparse([6,0,-1,-4,-1,0;...
    0,32,0,16,-4,16;...
    -1,0,6,0,-1,-4;...
    -4,16,0,32,0,16;...
    -1,-4,-1,0,6,0;...
    0,16,-4,16,0,32]); % Mass matrix block

M = sparse((2*m-1)^2,(2*m-1)^2);

AInt = (1/6)*sparse([6,-4,1,0,1,-4;...
    -4,16,-4,-8,0,0;...
    1,-4,3,0,0,0;...
    0,-8,0,16,0,-8;...
    1,0,0,0,3,-4;...
    -4,0,0,-8,-4,16]); % Stiffness matrix block

A = M;

% Assemble system matrices
for i = 1:size(tri,1)
    
    M(V(i,:),V(i,:)) = M(V(i,:),V(i,:)) + Jdet(i)*MInt; 
    A(V(i,:),V(i,:)) = A(V(i,:),V(i,:)) + Jdet(i)*AInt;
    
end

%% Prepare for iterations

I = speye(size(A,1));
null = sparse(size(A,1),size(A,2));
S = 1/k*[I,null;null,tau*M];
P = S - [null,I;-D*A,-M];
Dir = false((2*m-1)^2,1);   
Dir(Dir1) = true;
Dir(Dir2) = true;   % Dirichlet boundary flags
Dir = [Dir;false((2*m-1)^2,1)];
b = [zeros(length(Rg),1);-D*A*Rg];        % Transformed lifting vector

%% Interpolation Preperations

[x,y] = meshgrid((0:1/(2*s+2):1-1/(2*s+2))',(0:1/(2*s+2):1-1/(2*s+2))');
y = fliplr(y')';

phi1 = @(x,y) 1-3*x-3*y+4*x.*y+2*x.^2+2*y.^2;
phi2 = @(x,y) 4*x-4*x.*y-4*x.^2;
phi3 = @(x,y) -x+2*x.^2;
phi4 = @(x,y) 4*x.*y;
phi5 = @(x,y) -y+2*y.^2;
phi6 = @(x,y) 4*y-4*x.*y-4*y.^2;

xc = 1-x;
yc = 1-y;

Phi11 = tril(phi1(x,y),1);
Phi21 = tril(phi2(x,y),1);
Phi31 = tril(phi3(x,y),1);
Phi41 = tril(phi4(x,y),1);
Phi51 = tril(phi5(x,y),1);
Phi61 = tril(phi6(x,y),1);
Phi12 = triu(phi1(xc,yc),2);
Phi22 = triu(phi2(xc,yc),2);
Phi32 = triu(phi3(xc,yc),2);
Phi42 = triu(phi4(xc,yc),2);
Phi52 = triu(phi5(xc,yc),2);
Phi62 = triu(phi6(xc,yc),2);

U = zeros(K);

[y,x] = meshgrid(linspace(-1,1,K),linspace(-1,1,K));

%% Iterate and plot each time step

l = 1;
while true
    
    disp(l)  
    T(~Dir) = P(~Dir,~Dir)\(b(~Dir) + S(~Dir,~Dir)*T(~Dir)); % Solve on interior
    l = l+1;
    Tres = reshapeT(T(1:(2*m-1)^2),m); 
    
    % Construct interpolant
    for i = 1:m-1
    
        for j = 1:m-1
       
            U(1+2*(s+1)*(i-1):2*i*(s+1),1+2*(s+1)*(j-1):2*j*(s+1)) = ...
                Tres(1+2*(j-1)+2*(2*m-1)*(i-1))*Phi11 +...
                Tres(2+2*(j-1)+2*(2*m-1)*(i-1))*Phi21 +...
                Tres(3+2*(j-1)+2*(2*m-1)*(i-1))*(Phi31+Phi52) +...
                Tres(2*m+2*(j-1)+2*(2*m-1)*(i-1))*Phi61 +...
                Tres(2*m+1+2*(j-1)+2*(2*m-1)*(i-1))*(Phi41+Phi42) +...
                Tres(4*m-1+2*(j-1)+2*(2*m-1)*(i-1))*(Phi51+Phi32) +...
                Tres(4*m+1+2*(j-1)+2*(2*m-1)*(i-1))*Phi12 +...
                Tres(4*m+2*(j-1)+2*(2*m-1)*(i-1))*Phi22 +...
                Tres(2*m+2+2*(j-1)+2*(2*m-1)*(i-1))*Phi62;
        
        end
        
        U(end,end-2*(s+1)*(i-1):-1:end-2*(s+1)*i+1) =...
            Tres(end-2*(i-1))*Phi11(end,:)+...
            Tres(end-2*(i-1)-1)*Phi21(end,:)+...
            Tres(end-2*(i-1)-2)*Phi31(end,:);
        
        U(1+2*(s+1)*(i-1):2*(s+1)*i,end) =...
            Tres((2*m-1)*(2*i-1))*Phi51(:,1)+...
            Tres((2*m-1)*(2*i))*Phi61(:,1)+...
            Tres((2*m-1)*(2*i+1))*Phi11(:,1);
    
    end
    U(end,1) = Tres(end-2*(m-1));
    surf(x,y,fliplr(U')');  % Plot solution
    view(40 ,45);
    axis([-1,1,-1,1,-1.2,1.2]);
    xlabel('x')
    ylabel('y')
    drawnow;
    
end