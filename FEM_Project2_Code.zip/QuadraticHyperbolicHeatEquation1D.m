% 1D hyperbolic heat equation with quadratic elements

%% Set parameters

N = 200; % Number of element vertices
m = 11;   % Number of interpolation points in each element (must be odd)
K = N+1; % Number of elements
D = 1e2; % Thermal diffusivity
k = 1; % Time step
tau = 5e2; % Relaxation time

T1 = 1;
T2 = 0;  % Dirichlet boundary values

%% Triangulation

h = 1/K;     % Element size
x = (0:h:1)';   % Element vertex coordinates
xref = (0:1/(m-1):(m-2)/(m-1))'; % Interpolation node coordinates in 
                                    % reference element
phi1 = 2*xref.^2 -3*xref + 1;
phi2 = 4*xref.*(1-xref);
phi3 = 2*xref.^2-xref;      % Basis functions evaluated at nodes

V = [1:2:2*N+1;2:2:2*N+2;3:2:2*N+3]'; % Node coordinates on domain

%% Construct system matrices

X = x(1:end-1) - x(2:end);
absX = abs(X);      % Jacobian for all elements

MInt = (1/15)*[2,1,-1/2;1,8,1;-1/2,1,2]; % Mass matrix block
AInt = (1/3)*[7,-8,1;-8,16,-8;1,-8,7];  % Stiffness matrix block

M = sparse(2*N+3,2*N+3);
A = sparse(2*N+3,2*N+3);

% Assemble system matrices
for e = 1:K

    A(V(e,:),V(e,:)) = A(V(e,:),V(e,:)) + absX(e)*AInt;
    M(V(e,:),V(e,:)) = M(V(e,:),V(e,:)) + absX(e)*MInt;

end

%% Boundary conditions and initial data

B = false(2*N+3,1);
B(1) = true;
B(end) = true;
B = [B;B]; % Boundary flags

T = zeros(2*N+3,1);
DT = T;
Rg = zeros(2*N+3,1);
Rg([1,end]) = [T1;T2];
T(1) = Rg(1); T(end) = Rg(end); % Initial data
b = -D*A*Rg;
b = [0*b;b];    % Lifting vector

%% Prepare for iterations

x = 0:h/(m-1):1; % Node coordinates

S = 1/k*[speye(2*N+3),sparse(2*N+3,2*N+3);sparse(2*N+3,2*N+3),tau*M];
P = S + [sparse(2*N+3,2*N+3),-speye(2*N+3);D*A,M];
w = [T;DT];

U = zeros(1+(m-1)*K,1);

%% Iterate and plot each time step
i = 1;
figure(1)
while true
    
    w(~B) = P(~B,~B)\(b(~B)+S(~B,~B)*w(~B));
    T = w(1:2*N+3);
    disp(i)
    i = i+1;
    
    % Construct interpolant
    for e = 1:K
       
        U(1+(e-1)*(m-1):e*(m-1)) = T(1+2*(e-1))*phi1 + T(2+2*(e-1))*phi2 + ...
            T(3+2*(e-1))*phi3;
        
    end
    U(1) = T(1);
    U(end) = T(end);
    
    % Plot result
    plot(x,U);
    axis([0,1,-0.2,1.2]);
    drawnow;
    
end