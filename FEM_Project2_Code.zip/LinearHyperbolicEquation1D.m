% 1D hyperbolic heat equation with linear elements

%% Set parameters

N = 5000; % Number of internal points
K = N+1; % Number of elements
D = 1e5; % Thermal diffusivity
k = 1000; % Time step size
tau = 5e8; % Relaxation time

T1 = 1;  % Left hand side Dirichlet condition
T2 = 0;  % Right hand side Dirichlet condition

%% Triangulation

h = 1/K; % Length of elements
x = (0:h:1)';   % Grid coordinates

V = [1:K;2:K+1]'; % Element vertex indices

%% System matrices

X = x(1:end-1) - x(2:end);
absX = abs(X);      % Jacobian

MInt = [1/3,1/6;1/6,1/3];   % Mass matrix block
AInt = [1,-1;-1,1];     % Stiffness matrix block

M = sparse(N+2,N+2);   
A = sparse(N+2,N+2);

% Loop for building system matrices
for e = 1:K

    A(V(e,:),V(e,:)) = A(V(e,:),V(e,:)) + absX(e)*AInt;
    M(V(e,:),V(e,:)) = M(V(e,:),V(e,:)) + absX(e)*MInt;

end

%% Boundary conditions and initial data

B = false(N+2,1);
B(1) = true;
B(end) = true;
B = [B;B];  % Dirichlet boundary flag

T = zeros(2*N+4,1); 
Rg = zeros(N+2,1);
Rg(1) = T1;
Rg(end) = T2;
T(1) = T1;
T(N+2) = T2; % Initial data

Th = T; % Hyperbolic solution

%% Prepare for iterations

S = 1/k*[speye(N+2),sparse(N+2,N+2);sparse(N+2,N+2),0*M];
P = S + [sparse(N+2,N+2),-speye(N+2);D*A,speye(N+2)];
Sh = 1/k*[speye(N+2),sparse(N+2,N+2);sparse(N+2,N+2),tau*M];
Ph = Sh + [sparse(N+2,N+2),-speye(N+2);D*A,speye(N+2)];
b = -[zeros(N+2,1);D*A*Rg];

%% Writing to video
%v = VideoWriter('1DDirichletDirichlet.avi');
%v.FrameRate = 70;
%v.Quality = 100;
%open(v);

%% Begin iterations and plot each time step
i = 1;
figure(1)
while 1
    c = S*T;
    ch = Sh*Th;
    T(~B) = P(~B,~B)\(b(~B) + c(~B));
    Th(~B) = Ph(~B,~B)\(b(~B) + ch(~B));
    disp(double(i)/70)
    i = i+1;
    
    plot(x,T(1:N+2),'k');
    hold on
    plot(x,Th(1:N+2),'r');
    hold off
    axis([0,1,-0.2,1.2]);
    xlabel('$x$','interpreter','latex','fontsize',22)
    ylabel('$T$','interpreter','latex','fontsize',22)
    set(gca,'fontsize',20)
    legend({'Heat Equation','Hyperbolic Heat Equation'},'interpreter','latex')
    drawnow;
    
    %frame = getframe(gcf);
    %writeVideo(v,frame);
end
%close(v)