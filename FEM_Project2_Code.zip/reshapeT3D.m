function newT = reshapeT3D(T,m)

N = m+1;
M = N+m;

T1 = T(1:N^3);
T2 = T(N^3+1:M^3);

Tlogical = false(length(T2),1); % Initialize

for i = 1:N
    
    index = ([1:m*(M+N)]') + (i-1)*(m*(M+N)+M^2);
    Tlogical(index) = true;
    
end

T3 = T2(Tlogical);
T4 = T2(~Tlogical);

newT = zeros(M^3,1);

j=0;k=0;

for i = 1:M
    
    if mod(i,2) == 1
        
        addedT = T3(1+m*(M+N)*j:m*(M+N)+m*(M+N)*j);
        existingT = T1(1+N^2*j:N^2+N^2*j);
        index = ([1:2:M]'+[0:2*M:M^2])+(i-1)*M^2;
        index = index(:);
        newT(index) = existingT;
        index2 = ([2:2:M]'+[0:2*M:M^2])+(i-1)*M^2;
        index2 =index2(:);
        index3 = ([1:m]'+(M+m)*[0:m]);
        index3= index3(:);
        newT(index2) = addedT(index3);
        index4 = ([M+1:2*M]' + (2*M)*[0:m-1])+(i-1)*M^2;
        index4 = index4(:);
        index5 = ([m+1:m+M]'+(M+m)*[0:m-1]);
        index5 = index5(:);
        newT(index4) = addedT(index5);
        
        j = j+1;
        
    else
        
        newT((i-1)*M^2+1:i*M^2) = T4(1+M^2*k:M^2+M^2*k);
        k = k+1;
        
    end
    
    
end