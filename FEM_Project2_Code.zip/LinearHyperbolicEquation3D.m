% 3D hyperbolic heat equation with linear elements

%% Set parameters

m = 20; % nodes in each space direction
D = 1e2;     % Thermal diffusivity
T1 = 0;     
T2 = 1;     % Dirichlet boundary values
k = 3;    % Time step
tau = 1e2;  % Relaxation time

%% Define where slices are placed during plotting

slicex = [0.3,0.6,1];
slicey = [1];
slicez = [0,0.5];

%% Create Triangulation

numb = zeros(m^3,1);
for i = 1:m % Create base vector to construct triangulation
    temp = [1+(m+1)^2*(i-1):((m+1)^2)*i-(m+2)];
    temp(m+1:m+1:end) = [];
    numb(1+m^2*(i-1):i*m^2) = temp;
end
tri = [numb,numb+1,numb+(m+1)^2,numb+m+1;numb+(m+1)^2+m+2,numb+m+2,numb+(m+1)^2+m+1,numb+(m+1)^2+1]; % Add Corner tetrahedral elements
                                                                                                     % Lower left, then upper right
                                                                                                     % Elements 1 then 6 in base Delaunay on unit cube
tri = [tri;numb+(m+1)^2+m+1,numb+m+1,numb+(m+1)^2,numb+1]; % Element 2 in base Delaunay on unit cube
tri = [tri;numb+1,numb+m+2,numb+(m+1)^2+1,numb+(m+1)^2+m+1]; % Element 4 in base Delaunay on unit cube

tri = [tri;numb+m+1,numb+m+2,numb+(m+1)^2+m+1,numb+1]; % Element 3 in base Delaunay on unit cube
tri = [tri;numb+(m+1)^2,numb+(m+1)^2+1,numb+(m+1)^2+m+1,numb+1]; % Element 5 in base Delaunay on unit cube

[tempx,tempy,tempz] = meshgrid(linspace(0,1,m+1),linspace(0,1,m+1),linspace(0,1,m+1)); % Create mesh

x = tempy(:); % Reshape x. May appear strange, but for our numbering it works
y = tempz(:); % Reshape y. It is simpler than complicated reshaping.
z = tempx(:); % Reshape z

p = [x,y,z]; % Create point vector

V = tri;

%% Define Boundary Nodes

Front = [1:(m+1)^2];
Back = [m*(m+1)^2+1:(m+1)^3];
Up = ([(m+1)^2-m:(m+1)^2] + (m+1)^2*[0:m]')';
Up = Up(:);
Down = ([1:m+1] + (m+1)^2*[0:m]')';
Down = Down(:);
Left = ([1:m+1:(m+1)^2] + (m+1)^2*[0:m]')';
Left = Left(:);
Right = ([m+1:m+1:(m+1)^2] + (m+1)^2*[0:m]')';
Right = Right(:);

%% Calculate Jacobians

% As all elements are the same size, we only need to calculate the jacobian
% for 1 element, as it is the same for all

Jdet = abs(det([p(V(1,1),:)',p(V(1,2),:)',p(V(1,3),:)']-p(V(1,4),:)'));

%% Create Mass Matrix

MInt = (1/120)*[2,1,1,1;...
                1,2,1,1;...
                1,1,2,1;...
                1,1,1,2];

M = zeros((m+1)^3);

for i = 1:length(tri)
    
    M(V(i,:),V(i,:)) = M(V(i,:),V(i,:)) + Jdet*MInt;
    
end

%% Create Stiffness Matrix

A = zeros((m+1)^3);

AIntCor = (1/6)*[3,-1,-1,-1;... % A for Corner Elements (1 and 6)
                 -1,1,0,0;...
                 -1,0,1,0;...
                 -1,0,0,1];
             
for i = 1:2*m^3
    disp(i)
    A(V(i,:),V(i,:)) = A(V(i,:),V(i,:)) + Jdet*AIntCor;
    
end

AIntInt1 = (1/6)*[3,-2,-2,1;... % A for Internal Elements (2 and 4)
                  -2,2,1,-1;...
                  -2,1,2,-1;...
                  1,-1,-1,1];

for i = 2*m^3+1:4*m^3
    
    A(V(i,:),V(i,:)) = A(V(i,:),V(i,:)) + Jdet*AIntInt1;
    
end

AIntInt2 = (1/6)*[2,-1,-1,0;... % A for Internal Elements (3 and 5)
                  -1,2,0,-1;...
                  -1,0,1,0;...
                  0,-1,0,1];

for i = 4*m^3+1:6*m^3
    
    A(V(i,:),V(i,:)) = A(V(i,:),V(i,:)) + Jdet*AIntInt2;
    disp(i)
end

%% Implement Boundary Conditions and Initial Values

Dir = false((m+1)^3,1);
Dir(Right) = true;

Rg = zeros((m+1)^3,1);
Rg(Left) = T1;
Rg(Right) = T2;

T = zeros((m+1)^3,1);
T(Dir) = Rg(Dir);
T = [T;zeros(length(T),1)];
Dir = [Dir;Dir];

%% Create Matrices & Vectors for Iteration
I = speye(size(A,1));
null = sparse(size(A,1),size(A,2));
S = 1/k*[I,null;null,tau*M];
P = S - [null,I;-D*A,-M];
b = -D*(A*Rg);
b = [zeros(length(Rg),1);b];

%% Functions for creating video

%v = VideoWriter('3DDirichletNeumann.avi');
%v.FrameRate = 70;
%v.Quality = 100;
%open(v);

%% Iteration and Plotting

i = 1;

while double(i)/70 < 20
    
    disp(double(i)/70)  
    T(~Dir) = P(~Dir,~Dir)\(b(~Dir) + S(~Dir,~Dir)*T(~Dir)); % Solve on interior
    i = i+1;
    
    Tplot = permute(reshape(T(1:(m+1)^3),m+1,m+1,m+1),[2,1,3]);
    
    slice(tempx,tempy,tempz,Tplot,slicex,slicey,slicez);
    xlabel('$x$','interpreter','latex','fontsize',24)
    ylabel('$y$','interpreter','latex','fontsize',24)
    zlabel('$z$','interpreter','latex','fontsize',24)
    set(gca,'fontsize',20)
    caxis([-0.2,1.2])
    drawnow;
    
    %frame = getframe(gcf);
    %writeVideo(v,frame);
    
end
%close(v)