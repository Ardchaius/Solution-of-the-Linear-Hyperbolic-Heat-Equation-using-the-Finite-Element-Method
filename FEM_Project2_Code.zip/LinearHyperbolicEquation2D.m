% 2D hyperbolic heat equation with linear elements

%% Set parameters
m = 128;      % Number of grid nodes along each axis
N = m^2;      % Total number of nodes
n = m;        
D = 1e1;      % Thermal diffusivity
tau = 1e5;    % Relaxation time
T1 = 0;      
T2 = 1;     % Dirichlet boundary values
k = 50;    % Time step

%% Triangulation

[y,x] = meshgrid(linspace(-1,1,m), linspace(-1,1,m)); 
p = [x(:), y(:)];
T = zeros((n-1)*(m-1),1);
for i = 1:(n-1)
    T(1+(m-1)*(i-1):(m-1)*i) = (1+m*(i-1):m*i-1)';
end
tri = [T,T+1,T+m;T+m+1,T+m,T+1];
south = (1:m)';
east = (m:m:N)';
west = (N-m+1:-m:1)';
north = (N:-1:N-m+1)';
edge = [south,[south(2:end);east(2)];...
    east(2:end-1),east(3:end);...
    north,[north(2:end);east(2)];...
    west(2:end-1),west(3:end)];

V = tri; % node coordinates

Dir1 = (1:m:N)';
Dir2 = (m:m:N)'; 

B = edge(:,1);      % All boundary nodes

%% Construct system matrices

x1 = p(tri(:,1),:);
x2 = p(tri(:,2),:);
x3 = p(tri(:,3),:); 

J = [x1-x3,x2-x3];

Jdet = abs(J(:,4).*J(:,1) - J(:,2).*J(:,3)); % Jacobian for all elements

MInt = (1/24)*sparse([2,1,1;1,2,1;1,1,2]); % Mass matrix block

M = sparse(N,N);

AInt = (1/2)*sparse([2,-1,-1;-1,1,0;-1,0,1]); % Stiffness matrix block

A = sparse(N,N);

% Construct matrices
for i = 1:size(tri,1)
    fprintf('%i/%d\n',i,size(tri,1));
    M(V(i,:),V(i,:)) = M(V(i,:),V(i,:)) + Jdet(i)*MInt; 
    A(V(i,:),V(i,:)) = A(V(i,:),V(i,:)) + Jdet(i)*AInt;
    
end

%% Boundary conditions and initial data

Rg = zeros(N,1);  
Rg(Dir1) = T1;
Rg(Dir2) = T2;      % Lifting vector

T(B) = Rg(B);
T = [T;zeros(length(T),1)]; % Initial data

%% Prepare for iterations

I = speye(size(A,1));
null = sparse(size(A,1),size(A,2));
S = 1/k*[I,null;null,tau*M];
P = S - [null,I;-D*A,-M];
Dir = false(N,1);   
Dir(Dir1) = true;
Dir(Dir2) = true;   % Dirichlet boundary flags
Dir = [Dir;false(N,1)];
b = [zeros(length(Rg),1);-D*A*Rg];        % Transformed lifting vector

%% Video writing

%v = VideoWriter('2DNeumannNeumann.avi');
%v.FrameRate = 70;
%v.Quality = 100;
%open(v);

%% Iterate and plot each time step
x = reshape(p(:,1),m,m)';
y = fliplr(reshape(p(:,2),m,m)');
surf(x,y,reshape(T(1:m^2),m,m)');  % Plot initial data
view(-144,45);
axis([-1,1,-1,1,-5,10]);

%frame = getframe(gcf);
%writeVideo(v,frame);

i = 1;
while 1
      
    T(~Dir) = P(~Dir,~Dir)\(b(~Dir) + S(~Dir,~Dir)*T(~Dir)); % Solve on interior
    disp(double(i)/70)
    i = i+1;
    surf(x,y,reshape(T(1:m^2),m,m)');  % Plot solution
    view(-144,45);
    axis([-1,1,-1,1,-5,10]);
    xlabel('$x$','interpreter','latex','fontsize',24)
    ylabel('$y$','interpreter','latex','fontsize',24)
    zlabel('$T$','interpreter','latex','fontsize',24)
    set(gca,'fontsize',20)
    drawnow;
    
    %frame = getframe(gcf);
    %writeVideo(v,frame);
    
end
%close(v)