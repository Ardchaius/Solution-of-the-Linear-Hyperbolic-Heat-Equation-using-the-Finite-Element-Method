function newT = reshapeT(T,m)

T1 = T(1:m^2);
T2 = T(m^2+1:end);
Tlogical = false(length(T2),1); % Initialize

for i = 1:m
    
    % Indicate which new nodes exist on old rows.
    Tlogical(1+(i-1)*(3*m-2):(3*m*i-2*i-2*m+1)) = true;
    
end
T3 = T2(Tlogical);
T4 = T2(~Tlogical);

oldRowT = zeros(2*m^2-m,1);

for i = 1:m
    
    temp = reshape([(T1(1+m*(i-1):i*m))';[T3(1+(m-1)*(i-1):i*(m-1));0]'],[],1);
    temp(end) = [];
    oldRowT(1+(2*m-1)*(i-1):(2*m-1)*i) = temp;
    
end

newT = reshape([reshape((oldRowT(1:(m-1)*(2*m-1)))',2*m-1,m-1);reshape(T4,2*m-1,m-1)],[],1);
newT = [newT;oldRowT((m-1)*(2*m-1)+1:end)];