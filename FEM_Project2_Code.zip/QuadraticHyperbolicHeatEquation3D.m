% 3D hyperbolic heat equation with quadratic elements

%% Set parameters

m = 5; % elements in each space direction
N = m+1; % Nodes in each space direction
O = m+N; % Nodes in each spce direction including midpoints
D = 1e1;     % Diffusion coefficient
T1 = 0;     
T2 = 1;     % Dirichlet boundary values
k = 1;    % Time step
tau = 1e2;  % Relaxation time

%% Define where slices are placed during plotting

slicex = [0.3,0.6,1];
slicey = [1];
slicez = [0,0.5];


%% Create Triangulation

numb = zeros(m^3,1);
for i = 1:m % Create base vector to construct triangulation
    temp = [1+(m+1)^2*(i-1):((m+1)^2)*i-(m+2)];
    temp(m+1:m+1:end) = [];
    numb(1+m^2*(i-1):i*m^2) = temp;
end
tri = [numb,numb+1,numb+(m+1)^2,numb+m+1;numb+(m+1)^2+m+2,numb+m+2,numb+(m+1)^2+m+1,numb+(m+1)^2+1]; % Add Corner tetrahedral elements
                                                                                                     % Lower left, then upper right
                                                                                                     % Elements 1 then 6 in base Delaunay on unit cube
tri = [tri;numb+(m+1)^2+m+1,numb+m+1,numb+(m+1)^2,numb+1]; % Element 2 in base Delaunay on unit cube
tri = [tri;numb+1,numb+m+2,numb+(m+1)^2+1,numb+(m+1)^2+m+1]; % Element 4 in base Delaunay on unit cube

tri = [tri;numb+m+1,numb+m+2,numb+(m+1)^2+m+1,numb+1]; % Element 3 in base Delaunay on unit cube
tri = [tri;numb+(m+1)^2,numb+(m+1)^2+1,numb+(m+1)^2+m+1,numb+1]; % Element 5 in base Delaunay on unit cube

[tempx,tempy,tempz] = meshgrid(linspace(0,1,m+1),linspace(0,1,m+1),linspace(0,1,m+1)); % Create mesh

x = tempy(:); % Reshape x. May appear strange, but for our numbering it works
y = tempz(:); % Reshape y. It is simpler than complicated reshaping.
z = tempx(:); % Reshape z

p = [x,y,z]; % Create point vector

mid1 = zeros(length(tri)/6,1); % Lower left corner 1 to 2 midpoint
mid2 = zeros(length(tri)/6,1); % Lower left corner 2 to 3 midpoint
mid3 = zeros(length(tri)/6,1); % Lower left corner 4 to 1 midpoint

for i = 1:m
    
    temp1 = ([N^3+1:N^3+m]' + [0:m+O:(m+O)*(m-1)])+(m+m*O+m^2+O^2)*(i-1);
    temp2 = ([N^3+m*(O+N)+2:2:N^3+m*(2+O+N)]' + [0:2*O:(2*O)*(m-1)]) + (O^2+(O+N)*m)*(i-1);
    temp3 = ([N^3+m+1:2:N^3+3*m-1]' + [0:m+O:(m+O)*(m-1)]) + (O^2+m*(N+O))*(i-1);
    mid1(1+(m^2)*(i-1):m^2*i) = temp1(:);
    mid2(1+(m^2)*(i-1):m^2*i) = temp2(:);
    mid3(1+(m^2)*(i-1):m^2*i) = temp3(:);
    
end

V = zeros(size(tri,1),10);
V(:,1:2:7) = tri;

%Lower left corner start (Delaunay element 1)

V(1:end/6,2) = mid1; % 1 to 2
V(1:end/6,4) = mid2; % 2 to 3
V(1:end/6,6) = mid2 + (O-1); % 3 to 4
V(1:end/6,8) = mid3; % 4 to 1
V(1:end/6,9) = mid3 + 1; % 2 to 4
V(1:end/6,10) = mid2 - 1; % 1 to 3

%Lower left corner end (Delaunay element 1)

%Top right corner start (Delaunay element 6)

V(end/6+1:end/3,2) = mid2+2*O+1; % 1 to 2
V(end/6+1:end/3,4) = mid2+2*O; % 2 to 3
V(end/6+1:end/3,6) = mid3+m^2+O*m+O^2+m+1; % 3 to 4
V(end/6+1:end/3,8) = mid3+m^2+O*m+O^2+m+2; % 4 to 1
V(end/6+1:end/3,9) = mid2+O+1; % 2 to 4
V(end/6+1:end/3,10) = mid1+m^2+2*m+m*O+O^2+O; % 1 to 3

%Top right corner end (Delaunay element 6)

%Delaunay element 2 start

V(end/3+1:end/2,2) = mid2+2*O-1; % 1 to 2
V(end/3+1:end/2,4) = mid2 + (O-1); % 2 to 3
V(end/3+1:end/2,6) = mid2; % 3 to 4
V(end/3+1:end/2,8) = mid2+O; % 4 to 1
V(end/3+1:end/2,9) = mid3 + 1; % 2 to 4
V(end/3+1:end/2,10) = mid3+m^2+O*m+O^2+m; % 1 to 3

%Delaunay element 2 end

%Delaunay element 4 start

V(end/2+1:2*end/3,2) = mid3 + 2; % 1 to 2
V(end/2+1:2*end/3,4) = mid2+O+1; % 2 to 3
V(end/2+1:2*end/3,6) = mid3+m^2+O*m+O^2+m+1; % 3 to 4
V(end/2+1:2*end/3,8) = mid2+O; % 4 to 1
V(end/2+1:2*end/3,9) = mid2+2*O; % 2 to 4
V(end/2+1:2*end/3,10) = mid2+1; % 1 to 3

%Delaunay element 4 end

%Delaunay element 3 start

V(2*end/3+1:5*end/6,2) = mid1+m+O; % 1 to 2
V(2*end/3+1:5*end/6,4) = mid2+2*O; % 2 to 3
V(2*end/3+1:5*end/6,6) = mid2+O; % 3 to 4
V(2*end/3+1:5*end/6,8) = mid3 + 1; % 4 to 1
V(2*end/3+1:5*end/6,9) = mid3 + 2; % 2 to 4
V(2*end/3+1:5*end/6,10) = mid2+2*O-1; % 1 to 3

%Delaunay element 3 end

%Delaunay element 5 start

V(5*end/6+1:end,2) = mid1+m+m^2+m*O+O^2; % 1 to 2
V(5*end/6+1:end,4) = mid3+m^2+O*m+O^2+m+1; % 2 to 3
V(5*end/6+1:end,6) = mid2+O; % 3 to 4
V(5*end/6+1:end,8) = mid2; % 4 to 1
V(5*end/6+1:end,9) = mid2+1; % 2 to 4
V(5*end/6+1:end,10) = mid3+m^2+O*m+O^2+m; % 1 to 3

%Delaunay element 5 end


%% Define Boundary Nodes

Front = [1:(m+1)^2]';
Front = [Front;[N^3+1:N^3+1+m*(O+m)+m-1]'];
Back = [m*(m+1)^2+1:(m+1)^3]';
Back = [Back;[O^3:-1:O^3-(m-1)-m*(O+m)]'];
Up = ([(m+1)^2-m:(m+1)^2] + (m+1)^2*[0:m]')';
Up = Up(:);
Up2 = ([N^3+m*(m+O)+1:N^3+m*(m+O)+m]'+(O^2+m*(O+N))*[0:m]);
Up2 = Up2(:);
Up3 = ([N^3+O^2-O+m*(N+O)+1:N^3+O^2-O+m*(N+O)+O]'+(O^2+m*(O+N))*[0:m-1]);
Up3 = Up3(:);
Up = [Up;Up2;Up3];
Down = ([1:m+1] + (m+1)^2*[0:m]')';
Down = Down(:);
Down2 = ([N^3+1:N^3+m]'+(O^2+m*(O+N))*[0:m]);
Down2 = Down2(:);
Down3 = ([N^3+m*(O+N)+1:N^3+m*(O+N)+O]' + (O^2+m*(O+N))*[0:m-1]);
Down3 = Down3(:);
Down = [Down;Down2;Down3];
Left = ([1:m+1:(m+1)^2] + (m+1)^2*[0:m]')';
Left = Left(:);
Left2 = ([N^3+m+1:O+m:N^3+m+1+(m+O)*(m-1)]'+(O^2+m*(O+N))*[0:m]);
Left2 = Left2(:);
Left3 = ([N^3+m*(O+N)+1:O:N^3+m*(O+N)+1+(O-1)*O]' + (O^2+m*(O+N))*[0:m-1]);
Left3 = Left3(:);
Left = [Left;Left2;Left3];
Right = ([m+1:m+1:(m+1)^2] + (m+1)^2*[0:m]')';
Right = Right(:);
Right2 = ([N^3+m+O:O+m:N^3+m+O+(O+m)*(m-1)]' + (O^2+m*(O+N))*[0:m]);
Right2 = Right2(:);
Right3 = ([N^3+m*(O+N)+O:O:N^3+m*(O+N)+O+(O-1)*O]'+ (O^2+m*(O+N))*[0:m-1]);
Right3 = Right3(:);
Right = [Right;Right2;Right3];

Dir = false(O^3,1);
Dir([Left;Right]) = true;
Dir = [Dir;Dir];

%% Calculate Jacobians

% As all elements are the same size, we only need to calculate the jacobian
% for 1 element, as it is the same for all

Jdet = abs(det([p(tri(1,1),:)',p(tri(1,2),:)',p(tri(1,3),:)']-p(tri(1,4),:)'));

%% Create Mass Matrix

MInt = (1/2520)*[6,-4,1,-6,1,-6,1,-4,-6,-4;...
                 -4,32,-4,16,-6,8,-6,16,16,16;...
                 1,-4,6,-4,1,-6,1,-6,-4,-6;...
                 -6,16,-4,32,-4,16,-6,8,16,16;...
                 1,-6,1,-4,6,-4,1,-6,-6,-4;...
                 -6,8,-6,16,-4,32,-4,16,16,16;...
                 1,-6,1,-6,1,-4,6,-4,-4,-6;...
                 -4,16,-6,8,-6,16,-4,32,16,16;...
                 -6,16,-4,16,-6,16,-4,16,32,8;...
                 -4,16,-6,16,-4,16,-6,16,8,32];

M = zeros(O^3);

for i = 1:size(V,1)
    
    M(V(i,:),V(i,:)) = M(V(i,:),V(i,:)) + Jdet*MInt;
    
end

%% Create Stiffness Matrix

A = zeros(O^3);

AIntCor = (1/30)*[9,-6,1,2,1,2,1,-6,2,-6;... % A for Corner Elements (1 and 6)
                  -6,24,-4,-8,1,-8,1,4,-8,4;...
                  1,-4,3,-1,0,0,0,1,-1,1;...
                  2,-8,-1,16,-1,4,0,-8,4,-8;...
                  1,1,0,-1,3,-1,0,1,0,-4;...
                  2,-8,0,4,-1,16,-1,-8,4,-8;...
                  1,1,0,0,0,-1,3,-4,-1,1;...
                  -6,4,1,-8,1,-8,-4,24,-8,4;...
                  2,-8,-1,4,0,4,-1,-8,16,-8;...
                  -6,4,1,-8,-4,-8,1,4,-8,24];
             
for i = 1:2*m^3
    
    A(V(i,:),V(i,:)) = A(V(i,:),V(i,:)) + Jdet*AIntCor;
    
end

AIntInt1 = (1/30)*[9,-9,2,4,2,1,-1,0,1,-9;... % A for Internal Elements (2 and 4)
                   0,24,-8,-12,1,-4,0,0,4,4;...
                   0,0,6,1,-1,0,1,3,-5,1;...
                   0,0,0,40,1,0,2,-24,0,-12;...
                   0,0,0,0,6,-5,1,3,0,-8;...
                   0,0,0,0,0,16,-4,-12,4,4;...
                   0,0,0,0,0,0,3,2,-4,0;...
                   0,0,0,0,0,0,0,40,-12,0;...
                   0,0,0,0,0,0,0,0,16,-4;...
                   0,0,0,0,0,0,0,0,0,24];

AIntInt1= AIntInt1+tril(AIntInt1',-1);
               
for i = 2*m^3+1:4*m^3
    
    A(V(i,:),V(i,:)) = A(V(i,:),V(i,:)) + Jdet*AIntInt1;
    
end

AIntInt2 = (1/30)*[6,-5,1,2,1,1,0,-2,1,-5;... % A for Internal Elements (3 and 5)
                   0,24,-5,-4,1,-8,1,-4,0,0;...
                   0,0,6,-2,0,1,1,2,-5,1;...
                   0,0,0,24,-1,-4,1,-12,4,-8;...
                   0,0,0,0,3,-1,0,1,0,-4;...
                   0,0,0,0,0,16,-1,-4,0,0;...
                   0,0,0,0,0,0,3,-1,-4,0;...
                   0,0,0,0,0,0,0,24,-8,4;...
                   0,0,0,0,0,0,0,0,16,-4;...
                   0,0,0,0,0,0,0,0,0,16];

AIntInt2= AIntInt2+tril(AIntInt2',-1);               

for i = 4*m^3+1:6*m^3
    
    A(V(i,:),V(i,:)) = A(V(i,:),V(i,:)) + Jdet*AIntInt2;
    
end

%% Implement Boundary Conditions and Initial Values
Dir = false(O^3,1);
Dir([Left;Right]) = true;

Rg = zeros(O^3,1);
Rg(Left) = T1;
Rg(Right) = T2;

T = zeros(O^3,1);
T(Dir) = Rg(Dir);
T = [T;zeros(length(T),1)];
Dir = [Dir;Dir];

%% Create Matrices & Vectors for Iteration
I = speye(size(A,1));
null = sparse(size(A,1),size(A,2));
S = 1/k*[I,null;null,tau*M];
P = S - [null,I;-D*A,-M];
b = -D*(A*Rg);
b = [zeros(length(Rg),1);b];

%% Iteration and Plotting

i = 1;

[tempx,tempy,tempz] = meshgrid(linspace(0,1,O),linspace(0,1,O),linspace(0,1,O)); % Create mesh

while true
    
    disp(i)  
    T(~Dir) = P(~Dir,~Dir)\(b(~Dir) + S(~Dir,~Dir)*T(~Dir)); % Solve on interior
    i = i+1;
    
    Tplot = reshapeT3D(T(1:end/2),m);
    
    Tplot = permute(reshape(Tplot,O,O,O),[2,1,3]);
    
    slice(tempx,tempy,tempz,Tplot,slicex,slicey,slicez);
    xlabel('x')
    ylabel('y')
    zlabel('z')
    drawnow;
    
end